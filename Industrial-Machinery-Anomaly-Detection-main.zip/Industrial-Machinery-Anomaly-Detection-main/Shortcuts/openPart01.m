function openPart01
% Open file and cd into file directory. This script can be modified 
% to do whatever you'd like when clicking the project shortcut,
% e.g., loading data, running an app, or loading a doc page.

open("Part1_DataPrepFeatureExtraction.mlx")